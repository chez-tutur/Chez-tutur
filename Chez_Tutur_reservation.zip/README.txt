CHEZ TUTUR — MINI SYSTÈME DE RÉSERVATION GRATUIT

Ce pack contient :
- index.html : la jolie page que tu envoies à la Patronne.
- Code.gs : le petit serveur Google Apps Script qui reçoit les demandes et te donne une interface d'administration.

MISE EN PLACE (gratuit)

1. Va sur script.google.com et crée un nouveau projet.
2. Ouvre Code.gs et remplace son contenu par celui fourni dans ce pack.
3. Change ADMIN_CODE dans Code.gs si tu veux.
4. Clique Déployer > Nouveau déploiement > Application web.
5. Exécuter en tant que : Moi.
6. Qui a accès : Tout le monde.
7. Déploie et copie l'URL qui finit par /exec.
8. Dans index.html, remplace PASTE_YOUR_WEB_APP_URL_HERE par cette URL.
9. Héberge index.html gratuitement (GitHub Pages, Netlify ou Cloudflare Pages).
10. Envoie à la Patronne l'URL de la page.
11. Pour gérer les demandes, ouvre l'URL Apps Script suivie de ?admin=TON_CODE.
    Exemple : https://script.google.com/macros/s/XXXX/exec?admin=TUTUR-2026

IMPORTANT
- Le système utilise une feuille Google créée automatiquement pour stocker les demandes.
- La page d'administration permet d'accepter/refuser.
- La version actuelle affiche la demande comme "EN ATTENTE" côté invitée. Pour une notification automatique après acceptation, on peut ajouter un e-mail ou SMS dans une version 2.
- Pour garder le système vraiment personnel, garde l'URL d'administration privée et change ADMIN_CODE.
