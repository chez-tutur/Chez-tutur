/*
 * CHEZ TUTUR — Google Apps Script
 * 1) Crée un projet Apps Script
 * 2) Colle ce code dans Code.gs
 * 3) Déploie en "Application web" avec accès "Tout le monde"
 * 4) Copie l'URL /exec dans index.html à la place de PASTE_YOUR_WEB_APP_URL_HERE
 *
 * La première demande crée automatiquement une feuille "Réservations".
 * Pour l'interface privée : ouvre ton URL avec ?admin=TON_CODE
 * Change ADMIN_CODE ci-dessous avant de déployer.
 */

const ADMIN_CODE = "TUTUR-2026";

function doGet(e) {
  if (e && e.parameter && e.parameter.admin === ADMIN_CODE) {
    return HtmlService.createHtmlOutput(adminHtml_())
      .setTitle("Chez Tutur — Administration")
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  }
  return ContentService.createTextOutput("Chez Tutur — service de réservation actif.");
}

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents || "{}");
    if (data.row && data.status && data.admin === ADMIN_CODE) {
      getSheet_().getRange(Number(data.row),4).setValue(String(data.status));
      return json_({ok:true});
    }
    if (!data.name) throw new Error("Nom manquant");
    getSheet_().appendRow([new Date(), String(data.name), String(data.message || ""), "EN ATTENTE"]);
    return json_({ok:true});
  } catch(err) {
    return json_({ok:false,error:String(err)});
  }
}

function getSheet_() {
  const props = PropertiesService.getScriptProperties();
  let id = props.getProperty("SHEET_ID");
  let ss;
  if (id) {
    ss = SpreadsheetApp.openById(id);
  } else {
    ss = SpreadsheetApp.create("Chez Tutur — Réservations");
    const sh = ss.getSheets()[0];
    sh.setName("Réservations");
    sh.appendRow(["Date","Nom","Message","Statut"]);
    props.setProperty("SHEET_ID", ss.getId());
  }
  return ss.getSheetByName("Réservations");
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function adminHtml_() {
  const rows = getSheet_().getDataRange().getValues();
  let items = "";
  for (let i=1;i<rows.length;i++) {
    const d = rows[i][0] instanceof Date ? rows[i][0].toLocaleString("fr-FR") : rows[i][0];
    items += `<tr>
      <td>${esc_(d)}</td><td><b>${esc_(rows[i][1])}</b></td>
      <td>${esc_(rows[i][2])}</td><td><span class="badge">${esc_(rows[i][3])}</span></td>
      <td><button onclick="setStatus(${i+1},'ACCEPTEE')">ACCEPTER</button>
          <button class="no" onclick="setStatus(${i+1},'REFUSEE')">REFUSER</button></td>
    </tr>`;
  }
  if (!items) items = `<tr><td colspan="5" class="empty">Aucune demande pour le moment.</td></tr>`;
  return `<!doctype html><html lang="fr"><head><meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Chez Tutur — Administration</title>
  <style>
  body{margin:0;background:#f4efe5;color:#181613;font-family:Georgia,serif;padding:30px}
  .box{max-width:1100px;margin:auto;background:#fffdf8;padding:30px;box-shadow:0 15px 50px #0002}
  h1{font-weight:400}.gold{color:#b9975b} table{width:100%;border-collapse:collapse;margin-top:25px}
  th,td{padding:13px 9px;border-bottom:1px solid #ddd0bd;text-align:left;vertical-align:top}
  th{font:11px Arial;text-transform:uppercase;letter-spacing:1px;color:#756d61}
  button{background:#181613;color:white;border:0;padding:9px 12px;margin:2px;cursor:pointer;font-size:11px;letter-spacing:1px}
  button.no{background:#8c3f36}.badge{font:11px Arial;letter-spacing:1px}.empty{text-align:center;padding:35px;color:#756d61}
  </style></head><body><div class="box"><div class="gold">CHEZ TUTUR · ADMINISTRATION</div>
  <h1>Demandes de réservation</h1><table><tr><th>Date</th><th>Nom</th><th>Message</th><th>Statut</th><th>Action</th></tr>${items}</table></div>
  <script>
  function setStatus(row,status){
    fetch(location.href,{method:'POST',body:JSON.stringify({row:row,status:status,admin:"TUTUR-2026"})})
      .then(()=>location.reload()).catch(()=>alert('Erreur'));
  }
  </script></body></html>`;
}

function doPostAdmin_(e) {
  const d=JSON.parse(e.postData.contents||"{}");
  if(!d.row || !d.status) throw new Error("Paramètres manquants");
  getSheet_().getRange(Number(d.row),4).setValue(d.status);
  return json_({ok:true});
}

function esc_(s) {
  return String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;")
    .replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}
